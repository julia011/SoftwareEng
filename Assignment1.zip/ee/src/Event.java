
public abstract class Event<E extends Event<E>> implements Comparable<E>
{

    private int time;
    private char patientType;
    private int treatmentTime;
    private final Patient patient;
    private double currentTime;
    private double elapsedTime;
    private double startTime;
    private double endTime;



    public Event(int time, char patientType, int treatmentTime,Patient patient)
    {
        this.time = time;
        this.patientType = patientType;
        this.treatmentTime = treatmentTime;
        this.patient = patient;


    }
    @Override
    public int compareTo(Event o)
    {

            if (o.getTime() > this.getTime())
            {
                return -1;
            }
            else if (o.getTime() < this.getTime())
            {
                return 1;
            }
            else if (o.getPatientID() > this.getPatientID())
            {
                return -1;
            }
            else if (o.getPatientID() < this.getPatientID())
            {
                return 1;
            } else {
                System.out.println("Error");
                return 0;
            }

    }


    public int getTime()
    {
        return time;
    }

    public void setTime(int time)
    {
        this.time = time;
    }

    public char getPatientType()
    {
        return patientType;
    }

    public void setPatientType(char patientType)
    {
        this.patientType = patientType;
    }

    public int getTreatmentTime()
    {
        return treatmentTime;
    }

    public void setTreatmentTime(int treatmentTime)
    {
        this.treatmentTime = treatmentTime;
    }

    public Patient getPatient()
    {
        return this.patient;
    }

    public int getPatientID()
    {
        return this.patient.getPatientID();
    }
    public int getPriorityNumber()
    {
        return this.patient.getPriorityNumber();
    }

    public double getTimeElapsed()
    {
        elapsedTime = endTime-startTime;
        return elapsedTime;
    }
    /**
     * The startTime method is used to run a simulation for a specified period of simulated time.
     * Time will start at 0 and jump from event time to event time until either this period is over,
     * there are no more scheduled events, or the stopTime method is called.
     * @return
     */
    public static double startTime(double startTime)
    {
         startTime= System.nanoTime();


        return startTime;
    }



    public static void stopTime(double endTime)
    {
         endTime = System.nanoTime();
    }

    public abstract Event getNextEvent(int time, char patientType, int treatmentTime,Patient patient);

    public abstract void updateStatistics(Statistics statistics);

}
