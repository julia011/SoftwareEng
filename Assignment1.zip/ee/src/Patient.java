import java.util.*;

/**
 * Patient class is used to hold all patient info
 */
public class Patient
{
   private static int counter = 28064212;
   private final int patientID;
   private final double patientWaitingTime;
   private int priorityNumber;

    public Patient(double patientWaitingTime)
    {
        this.patientWaitingTime = patientWaitingTime;
        this.patientID = counter;
        counter++;
        priorityNumber = 0;
    }


    public int getPatientID()
    {
        return this.patientID;
    }

    public double getPatientWaitingTime()
    {
        return this.patientWaitingTime;
    }
    public int getPriorityNumber()
    {
        return this.priorityNumber;
    }

}
//--------------------------------------------------------------------------------------
/**
 * Takes stats for how many patients are arriving and the total waiting time.
 */
class Statistics
{   private double waitingTime = 0;
    private int numPatients =0;

    public Statistics(){}

    public void increasePatients()
    {
        numPatients++;
    }

    public void increaseWaitingTime(double time)
    {
        waitingTime += time;
    }


    @Override
    public String toString()
    {
        double x = waitingTime/numPatients;

        return "Patients seen in total  " + numPatients +"\n"
                + "Average waiting time per patient  " + x;
    }
}