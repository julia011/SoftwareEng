import java.util.PriorityQueue;
import java.util.Scanner;
import java.util.*;


/**
* Arrival Event occurs when patients enter hospital.
* Sends 'W' to Assessment Event
* Sends 'E' to WaitingRoom
* toString for printing arrival time, patient #, E OR W, "ARRIVES"
 */
public class ArrivalEvent extends Event
{
    /**
     * Creates an ArrivalEvent.
     * @param patient patient that the event is involving
     * @param patientType indicator of walk-ins or emergency patients
     * @param treatmentTime how long patient requires for treatment
     * @param time time at which event is created.
     */
    public ArrivalEvent(int time, char patientType, int treatmentTime,Patient patient)
    { super(time, patientType, treatmentTime, patient);}

    /**
     * Creates nextEvent based off set of conditions
     * @param patient patient that the event is involving
     * @param patientType indicator of walk-ins or emergency patients
     * @param treatmentTime how long patient requires for treatment
     * @param time time at which event is created.
     * @return AssessmentEvent if its a Walk-in patient,
     * WaitingRoom Event is its and Emergency patient
     * null if the incorrect char was given for patient type
     */
    public Event getNextEvent(int time, char patientType, int treatmentTime,Patient patient)
    {
        if(patientType == 'W')
        {   startTime(time);
            System.out.print("Walk-in");
            stopTime(startTime(time));
            return createAssessmentEvent();


        }
        else if(patientType == 'E')
        {

            System.out.println("(Emergency)");
            return createWaitingRoomEvent();
        }
        else
        {
            System.out.print("Patient Type must be a Caps W or E");
            return null;

        }

    }
    public void getPriority(char patientType)
    {
        if(patientType == 'E')
        {
            //int priorityNumber =1;

        }
        else if(patientType == 'E')
        {
            Random x = new Random(1000);
            //priorityNumber = x.nextInt((5-2)+2);
        }
        else
        { }
    }

    public void updateStatistics(Statistics statistics)
    {
            statistics.increasePatients();
    }
    /**
     * Creates an Assessment Event
     * @return AssessmentEvent
     */
    public AssessmentEvent createAssessmentEvent()
    {
        return new AssessmentEvent(this.getTime(),this.getPatientType(), this.getTreatmentTime(), this.getPatient());
    }
    /**
     * Creates an WaitingRoom Event
     * @return WaitingRoomEvent
     */
    public WaitingRoomEvent createWaitingRoomEvent()
    {
        return new WaitingRoomEvent(this.getTime(),this.getPatientType(), this.getTreatmentTime(), this.getPatient());
    }

    @Override
    public String toString()
    {
        return "Time " + this.getTime() + " : " + this.getPatientID() + " arrives" + getTimeElapsed();
    }


}

//--------------------------------------------------------------------------------------

/**
 *Assessment for all Walk-in Patients.
 * Gives a random priority number form 2-5 in a Queue system.
 * toString prints "starts assessment" when getting to beginning on line
 * Assessment takes 4 units of time
 */
class AssessmentEvent extends Event
{
    public AssessmentEvent(int time, char patientType, int treatmentTime, Patient patient)
    {
        super(time, patientType, treatmentTime, patient);
    }




    public Event getNextEvent(int time, char patientType, int treatmentTime,Patient patient)
    {
        Queue<Patient> assessment = new LinkedList<>();
        assessment.add(patient);

        while(assessment.size()>0)
        {
             Patient newPatient = assessment.element();
             getPriorityNumber();



        }


        return createWaitingRoomEvent();

    }
    /**
     * Creates an WaitingRoom Event
     * @return WaitingRoomEvent
     */
    public WaitingRoomEvent createWaitingRoomEvent()
    {
        return new WaitingRoomEvent(this.getTime(),this.getPatientType(), this.getTreatmentTime(), this.getPatient());
    }
    public void updateStatistics(Statistics statistics)
    {

    }

    @Override
    public String toString()
    {

        return "Time : " + this.getTime() +"," + this.getPatientID() + " assess";
    }


}

//--------------------------------------------------------------------------------------

/**
 * Waiting Room class holds patients waiting to get into treatment event
 * Requires a priority queue based off priority number, if patients have same
 * priority number, go ogg of patient ID number.
 */
class WaitingRoomEvent extends Event
{

    public WaitingRoomEvent(int arrivalTime, char patientType, int treatmentTime, Patient patient) {
        super(arrivalTime, patientType, treatmentTime, patient);
    }


    public Event getNextEvent(int time, char patientType, int treatmentTime,Patient patient) {
        PriorityQueue<Patient> waitingRoom = new PriorityQueue<>();
        while(waitingRoom.size()>0)
        {
            //if(treatment room one is empty go there)

            //else if(treatment room two is empty go there)

            //else if(treatment room three is empty go there)

            //else(wait, start wait time)
        }
        return null;
    }


    public int compareTo(Patient o)
    {

        if (o.getPriorityNumber() > this.getPriorityNumber())
        {
            return -1;
        }
        else if (o.getPriorityNumber() < this.getPriorityNumber())
        {
            return 1;
        }
        else if (o.getPatientID() > this.getPatientID())
        {
            return -1;
        }
        else if (o.getPatientID() < this.getPatientID())
        {
            return 1;
        } else {
            System.out.println("Error");
            return 0;
        }

    }

    public void updateStatistics(Statistics statistics)
    {

    }

}

//--------------------------------------------------------------------------------------
/**
 * Testing the program with scanner.
 * Needs to be implemented with buffer reader that only takes one event at a time.
 */
class Test
{
     public static void main(String[] args)
    {

        int time = 0;
        PriorityQueue<Event> event = new PriorityQueue<>();
        Statistics statistics = new Statistics();
        Patient patient = new Patient(time);


        Scanner sc = new Scanner(System.in);
        System.out.println("arrival time");
        int arrivalTime = sc.nextInt();
        System.out.println("Patient Type");
        char patientType = sc.next().charAt(0);
        System.out.println("Treatment time");
        int treatmentTime = sc.nextInt();
        sc.close();
        event.add(new ArrivalEvent(arrivalTime, patientType, treatmentTime, patient));


        while (event.size() > 0)
        {
            //startTime();
            Event firstEvent = event.poll();
            System.out.println(firstEvent);
            Event newEvent = firstEvent.getNextEvent(time, patientType, treatmentTime, patient);
            if (newEvent != null)
            {
                newEvent.updateStatistics(statistics);
                event.add(newEvent);
            }
            System.out.println(event);
        }

        System.out.println(statistics);
       }
}















